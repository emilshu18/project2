enum RoleModel {
    Admin,
    User
};

export default RoleModel;